package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Ticket;

import com.example.demo.repository.TicketRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class TicketController {
	@Autowired
	TicketRepository ticketRepository;
	@PostMapping("/tickets")
	public ResponseEntity<Ticket> createTicket(@RequestBody Ticket t)
	{
		
		try
		{
	   	   Ticket	_ticket= ticketRepository.save(new Ticket(t.getPnr(),t.getTrain_name(),t.getTravel_date(),t.getNo_of_pass(),t.getTotal_fare()));
	       return new ResponseEntity<>(_ticket,HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/tickets")
	public ResponseEntity<List<Ticket>> getAllTicket()
	{
		
		try
		{
	   	   List<Ticket> ticket_=new ArrayList<Ticket>();
	   	   ticketRepository.findAll().forEach(ticket_::add);
	       return new ResponseEntity<>(ticket_,HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/tickets/{id}")
	public ResponseEntity<Ticket> getTicketById(@PathVariable("id") int id)
	{
		
		
			Optional<Ticket> userData=ticketRepository.findById(id);
			if(userData.isPresent()) {
				 return new ResponseEntity<>(userData.get(), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		
			
	}
	@PutMapping("/tickets/{id}")
	public ResponseEntity<Ticket> updateTicket(@PathVariable("id") int id,@RequestBody Ticket t)
	{
		
		
			Optional<Ticket> ticketData=ticketRepository.findById(id);
			if(ticketData.isPresent()) {
				Ticket _ticket=ticketData.get();
				_ticket.setPnr(t.getPnr());
				_ticket.setTrain_name(t.getTrain_name());
				_ticket.setTravel_date(t.getTravel_date());
				_ticket.setNo_of_pass(t.getNo_of_pass());
				
				_ticket.setTotal_fare(t.getTotal_fare());
				 return new ResponseEntity<>(ticketRepository.save(_ticket), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		
			
	} 
	
	@DeleteMapping("/tickets/{id}")
	public ResponseEntity<HttpStatus> deleteTicket(@PathVariable("id") int id){
		
		try
		{
			ticketRepository.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	
	

}
